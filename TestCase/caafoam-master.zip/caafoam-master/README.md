# caafoam
Density based OpenFOAM solvers for Computational Aeroacoustics.

The solvers were developed and tested using OpenFOAM v2.3.x

Reference:
V. D'Alessandro, M. Falone, R. Ricci.  Direct computation of aeroacoustic fields 
in laminar flows: solver development and assessment of wall temperature effects 
on radiated sound around bluff bodies. Comput. & Fluids (2020)
